# Turmeric Leaf Disease Classification — reconstructed code

This package is a newly prepared implementation based on the experiment details available in the manuscript discussion. It is NOT recovered from the original Git repository and cannot reproduce the original weights, logs, or exact accuracies.

## Dataset
Arrange the downloaded Kaggle dataset as:
dataset/
  Healthy Leaf/
  Leaf Blotch/
  Dry Leaf/

The script expects image files in those three folders. It creates a stratified 70:15:15 split and saves the split manifest.

## Install and run
Python 3.10 or 3.11 recommended.

    pip install -r requirements.txt
    python src/run_experiment.py --data_dir dataset --model all

Use --model mobilenetv3, efficientnetv2b0, resnet50, or vit_b16 to run one model.

## Implemented settings
224x224 images, batch size 32, Adam, learning rate 1e-4, categorical cross-entropy,
maximum 150 epochs, early stopping on validation loss (patience 7), random seed 42.

## Important model limitation
MobileNetV3-Large, EfficientNetV2B0, and ResNet50 use ImageNet-pretrained Keras weights.
The included ViT-B16 is a custom patch-transformer trained from random initialization;
it is NOT an ImageNet-1K-pretrained ViT-B16. The exact original ViT checkpoint/library
is needed to reproduce that experiment faithfully.

Outputs are saved in a timestamped folder under outputs/: model weights, training curves
(600 dpi), history CSV, test predictions, confusion matrices, classification reports,
metrics JSON, split manifest, and run.log.

Do not claim these are the original repository's logs or that the code guarantees the
paper's reported accuracies. Run it on the exact dataset and report the results produced.
