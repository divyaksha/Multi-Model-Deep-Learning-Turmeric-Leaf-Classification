import argparse, json, logging, os, random, sys
from datetime import datetime
from pathlib import Path

import numpy as np
import pandas as pd
import tensorflow as tf
import matplotlib.pyplot as plt
from sklearn.model_selection import train_test_split
from sklearn.metrics import accuracy_score, confusion_matrix, classification_report, precision_recall_fscore_support

CLASSES = ["Healthy Leaf", "Leaf Blotch", "Dry Leaf"]
SEED = 42
SIZE = (224, 224)

def seed_everything():
    os.environ["PYTHONHASHSEED"] = str(SEED)
    random.seed(SEED); np.random.seed(SEED); tf.random.set_seed(SEED)

def collect_images(root):
    rows = []
    for cls in CLASSES:
        folder = Path(root) / cls
        if not folder.is_dir():
            raise FileNotFoundError(f"Missing class directory: {folder}")
        for p in folder.rglob("*"):
            if p.suffix.lower() in {".jpg", ".jpeg", ".png", ".bmp", ".webp"}:
                rows.append({"path": str(p.resolve()), "label": cls})
    df = pd.DataFrame(rows)
    if df.empty: raise RuntimeError("No images found.")
    print("Class counts:\\n", df.label.value_counts().reindex(CLASSES, fill_value=0))
    if any((df.label.value_counts().reindex(CLASSES, fill_value=0) == 0)):
        raise RuntimeError("At least one class is empty.")
    return df

def split_data(df, out):
    train, temp = train_test_split(df, test_size=.30, stratify=df.label, random_state=SEED)
    val, test = train_test_split(temp, test_size=.50, stratify=temp.label, random_state=SEED)
    parts = []
    for name, part in [("train", train), ("validation", val), ("test", test)]:
        part = part.copy(); part["split"] = name; parts.append(part)
    pd.concat(parts).to_csv(out / "split_manifest.csv", index=False)
    counts = []
    for name, part in [("train", train), ("validation", val), ("test", test)]:
        for cls in CLASSES:
            counts.append({"split": name, "class": cls, "count": int((part.label == cls).sum())})
    pd.DataFrame(counts).to_csv(out / "class_counts.csv", index=False)
    return train, val, test

def load_image(path, label):
    x = tf.io.read_file(path)
    x = tf.io.decode_image(x, channels=3, expand_animations=False)
    x.set_shape([None, None, 3])
    x = tf.image.resize(x, SIZE)
    return tf.cast(x, tf.float32), tf.one_hot(label, len(CLASSES))

def dataset(df, batch, shuffle=False):
    ids = {c:i for i,c in enumerate(CLASSES)}
    ds = tf.data.Dataset.from_tensor_slices((df.path.values, df.label.map(ids).values.astype("int32")))
    if shuffle: ds = ds.shuffle(len(df), seed=SEED, reshuffle_each_iteration=True)
    return ds.map(load_image, num_parallel_calls=tf.data.AUTOTUNE).batch(batch).prefetch(tf.data.AUTOTUNE)

def make_cnn(name):
    if name == "mobilenetv3":
        backbone = tf.keras.applications.MobileNetV3Large(include_top=False, weights="imagenet",
                    input_shape=(224,224,3), include_preprocessing=True)
        preprocess = None
    elif name == "efficientnetv2b0":
        backbone = tf.keras.applications.EfficientNetV2B0(include_top=False, weights="imagenet",
                    input_shape=(224,224,3), include_preprocessing=True)
        preprocess = None
    elif name == "resnet50":
        backbone = tf.keras.applications.ResNet50(include_top=False, weights="imagenet",
                    input_shape=(224,224,3))
        preprocess = tf.keras.applications.resnet50.preprocess_input
    else: raise ValueError(name)
    backbone.trainable = False
    inp = tf.keras.Input((224,224,3)); x = inp
    if preprocess: x = tf.keras.layers.Lambda(preprocess)(x)
    x = backbone(x, training=False)
    x = tf.keras.layers.GlobalAveragePooling2D()(x)
    x = tf.keras.layers.Dropout(.3)(x)
    out = tf.keras.layers.Dense(3, activation="softmax")(x)
    return tf.keras.Model(inp, out)

def make_vit():
    # Compact custom ViT-B16-style architecture; trained from scratch, not ImageNet pretrained.
    inp = tf.keras.Input((224,224,3))
    x = tf.keras.layers.Conv2D(128, 16, strides=16)(inp)
    x = tf.keras.layers.Reshape((196,128))(x)
    pos = tf.keras.layers.Embedding(196,128)(tf.range(196))
    x = x + pos
    for _ in range(4):
        y = tf.keras.layers.LayerNormalization(epsilon=1e-6)(x)
        y = tf.keras.layers.MultiHeadAttention(num_heads=4, key_dim=32, dropout=.1)(y,y)
        x = tf.keras.layers.Add()([x,y])
        y = tf.keras.layers.LayerNormalization(epsilon=1e-6)(x)
        y = tf.keras.layers.Dense(256, activation="gelu")(y)
        y = tf.keras.layers.Dropout(.1)(y)
        y = tf.keras.layers.Dense(128)(y)
        x = tf.keras.layers.Add()([x,y])
    x = tf.keras.layers.LayerNormalization(epsilon=1e-6)(x)
    x = tf.keras.layers.GlobalAveragePooling1D()(x)
    x = tf.keras.layers.Dropout(.3)(x)
    return tf.keras.Model(inp, tf.keras.layers.Dense(3, activation="softmax")(x))

def save_curves(hist, path, name):
    h = hist.history
    fig, ax = plt.subplots(1,2,figsize=(11,4))
    ax[0].plot(h["accuracy"], label="Training accuracy")
    ax[0].plot(h["val_accuracy"], label="Validation accuracy")
    ax[0].set(title=f"{name} accuracy", xlabel="Epoch", ylabel="Accuracy"); ax[0].legend()
    ax[1].plot(h["loss"], label="Training loss")
    ax[1].plot(h["val_loss"], label="Validation loss")
    ax[1].set(title=f"{name} loss", xlabel="Epoch", ylabel="Loss"); ax[1].legend()
    fig.tight_layout(); fig.savefig(path, dpi=600, bbox_inches="tight"); plt.close(fig)

def train_one(name, train, val, test, args, out):
    folder = out / name; folder.mkdir(parents=True, exist_ok=True)
    tr, va, te = dataset(train,args.batch_size,True), dataset(val,args.batch_size), dataset(test,args.batch_size)
    model = make_vit() if name == "vit_b16" else make_cnn(name)
    model.compile(optimizer=tf.keras.optimizers.Adam(args.learning_rate),
                  loss="categorical_crossentropy", metrics=["accuracy"])
    callbacks = [
        tf.keras.callbacks.ModelCheckpoint(str(folder/"best_model.keras"), monitor="val_loss",
                                           save_best_only=True, mode="min"),
        tf.keras.callbacks.EarlyStopping(monitor="val_loss", patience=7,
                                         restore_best_weights=True, mode="min"),
        tf.keras.callbacks.CSVLogger(str(folder/"history.csv"))
    ]
    hist = model.fit(tr, validation_data=va, epochs=args.epochs, callbacks=callbacks)
    save_curves(hist, folder/"training_curves.png", name)
    model = tf.keras.models.load_model(folder/"best_model.keras")
    probs = model.predict(te); pred = probs.argmax(1)
    truth = np.concatenate([y.numpy().argmax(1) for _,y in te])
    cm = confusion_matrix(truth,pred,labels=[0,1,2])
    pd.DataFrame(cm,index=CLASSES,columns=CLASSES).to_csv(folder/"confusion_matrix.csv")
    (folder/"classification_report.txt").write_text(
        classification_report(truth,pred,target_names=CLASSES,zero_division=0),encoding="utf-8")
    paths = test.path.tolist()
    pd.DataFrame({"image_path":paths,"actual_label":[CLASSES[i] for i in truth],
                  "predicted_label":[CLASSES[i] for i in pred],
                  "correct":truth==pred}).to_csv(folder/"test_predictions.csv",index=False)
    fig,ax=plt.subplots(figsize=(6,5)); im=ax.imshow(cm); fig.colorbar(im,ax=ax)
    ax.set(xticks=range(3),yticks=range(3),xticklabels=CLASSES,yticklabels=CLASSES,
           xlabel="Predicted class",ylabel="Actual class",title=f"{name} confusion matrix")
    plt.setp(ax.get_xticklabels(),rotation=25,ha="right")
    for i in range(3):
        for j in range(3): ax.text(j,i,str(cm[i,j]),ha="center",va="center")
    fig.tight_layout(); fig.savefig(folder/"confusion_matrix.png",dpi=600,bbox_inches="tight"); plt.close(fig)
    p,r,f,s=precision_recall_fscore_support(truth,pred,labels=[0,1,2],zero_division=0)
    result={"model":name,"test_accuracy":float(accuracy_score(truth,pred)),
            "class_precision":p.tolist(),"class_recall":r.tolist(),"class_f1":f.tolist(),
            "support":s.tolist(),"confusion_matrix":cm.tolist(),
            "epochs_completed":len(hist.history["loss"])}
    (folder/"metrics.json").write_text(json.dumps(result,indent=2),encoding="utf-8")
    logging.info("%s test accuracy %.4f",name,result["test_accuracy"])
    return result

def main():
    ap=argparse.ArgumentParser()
    ap.add_argument("--data_dir",required=True)
    ap.add_argument("--model",default="all",choices=["all","mobilenetv3","efficientnetv2b0","resnet50","vit_b16"])
    ap.add_argument("--epochs",type=int,default=150)
    ap.add_argument("--batch_size",type=int,default=32)
    ap.add_argument("--learning_rate",type=float,default=1e-4)
    a=ap.parse_args(); seed_everything()
    out=Path("outputs")/("run_"+datetime.now().strftime("%Y%m%d_%H%M%S")); out.mkdir(parents=True)
    logging.basicConfig(level=logging.INFO,format="%(asctime)s %(levelname)s %(message)s",
        handlers=[logging.FileHandler(out/"run.log",encoding="utf-8"),logging.StreamHandler(sys.stdout)])
    logging.info("TensorFlow %s",tf.__version__)
    df=collect_images(a.data_dir); train,val,test=split_data(df,out)
    names=["mobilenetv3","efficientnetv2b0","resnet50","vit_b16"] if a.model=="all" else [a.model]
    results=[train_one(n,train,val,test,a,out) for n in names]
    pd.DataFrame([{"model":x["model"],"test_accuracy_percent":100*x["test_accuracy"]} for x in results]).to_csv(out/"model_comparison.csv",index=False)
    (out/"all_metrics.json").write_text(json.dumps(results,indent=2),encoding="utf-8")
    logging.info("Completed. Outputs saved to %s",out.resolve())

if __name__=="__main__": main()
